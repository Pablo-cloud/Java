/**
 * Diese Klasse startet den Zoo und darf nicht veraendert werden
 */
public class WildeTiereStarter {
  public static void main (String[] args) {
    // Zoo-Objekt erstellen und Programm-Ablauf starten
    Zoo meinZoo = new Zoo();
    meinZoo.losGehts();
  }
}
