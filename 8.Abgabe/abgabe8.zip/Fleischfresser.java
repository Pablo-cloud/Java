public interface Fleischfresser{

public abstract void knochenZerbeissen();
}