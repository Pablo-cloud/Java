public interface Pflanzenfresser{

public abstract void pflanzenZerkauen();
}