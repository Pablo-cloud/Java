/**
 * DIESE DATEI NICHT AENDERN
 */
public interface KannTanken {

  public abstract void tanken();

}
