/**
 * DIESE DATEI NICHT AENDERN
 */
public abstract class Boeing extends VerkehrsFlugzeug {

  public Boeing(String einTyp) {
    super(einTyp);
  }

}
