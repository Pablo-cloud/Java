public class LeiderKaputt extends Exception {
	
}